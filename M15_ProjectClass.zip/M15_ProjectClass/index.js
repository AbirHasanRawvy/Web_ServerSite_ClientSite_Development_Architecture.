//We lessene all the file here.
const app = require("./app");

app.listen(5000, () => {
    console.log("Surver Running.....");
});