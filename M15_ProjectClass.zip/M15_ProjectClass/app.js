//Here all the security middleware is will write down.
// Basic setup;
const express = require("express");


//Secirity Middleware;
const app = express();

module.exports = app;